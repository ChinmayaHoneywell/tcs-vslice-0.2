Benchmark
=========

This project provides tests for ensuring the services and libraries provided as csw adheres to the 
NFR's specified by TMT.