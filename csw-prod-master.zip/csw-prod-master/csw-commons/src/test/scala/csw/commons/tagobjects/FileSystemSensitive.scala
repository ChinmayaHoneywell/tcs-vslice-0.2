package csw.commons.tagobjects

import org.scalatest.Tag

object FileSystemSensitive extends Tag("csw.commons.tags.FileSystemSensitive") {}
