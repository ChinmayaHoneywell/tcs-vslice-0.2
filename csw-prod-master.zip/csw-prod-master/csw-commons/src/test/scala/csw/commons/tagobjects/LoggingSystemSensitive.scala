package csw.commons.tagobjects

import org.scalatest.Tag

object LoggingSystemSensitive extends Tag("csw.commons.tags.LoggingSystemSensitive") {}
