package csw.apps.clusterseed.commons

import csw.services.logging.scaladsl.LoggerFactory

private[clusterseed] object ClusterSeedLogger extends LoggerFactory("cluster-seed-app")
