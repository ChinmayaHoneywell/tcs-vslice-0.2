package csw.apps.clusterseed.location

class QueryFilterException(msg: String) extends RuntimeException(msg)
