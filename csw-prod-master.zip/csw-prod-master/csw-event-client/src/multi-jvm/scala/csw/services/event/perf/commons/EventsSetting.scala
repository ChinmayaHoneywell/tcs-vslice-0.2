package csw.services.event.perf.commons

case class EventsSetting(totalTestMsgs: Long, payloadSize: Int, warmup: Int, rate: Int)
