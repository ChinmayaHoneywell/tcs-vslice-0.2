Configuration CLI client
=========================

Configuration Service is used to store and track changes in configurations used by components.

Configuration CLI Client can be used to interact with configuration service using a command line interface.

If you want to get started with using CLI client, refer the [examples](https://tmtsoftware.github.io/csw-prod/apps/cswconfigclientcli.html)