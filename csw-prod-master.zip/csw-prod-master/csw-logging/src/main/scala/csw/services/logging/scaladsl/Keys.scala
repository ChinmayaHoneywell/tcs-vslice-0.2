package csw.services.logging.scaladsl

/**
 * Consumer of logging service can use predefined keys below, while calling Logger api methods
 */
object Keys {
  val OBS_ID = "obsId"
}
