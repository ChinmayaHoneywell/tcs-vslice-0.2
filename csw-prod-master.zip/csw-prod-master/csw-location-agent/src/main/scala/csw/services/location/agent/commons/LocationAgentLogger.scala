package csw.services.location.agent.commons

import csw.services.logging.scaladsl.LoggerFactory

private[location] object LocationAgentLogger extends LoggerFactory("location-agent-app")
