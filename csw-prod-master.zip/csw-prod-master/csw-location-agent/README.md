Csw location agent
==================

Csw location agent provides a standalone application that is a simple wrapper for an external application to  
register it with the location service and unregister it when it exits.

If you want to get started with agent, refer the [examples](https://tmtsoftware.github.io/csw-prod/apps/cswlocationagent.html).

You can refer to Scala documentation [here](https://tmtsoftware.github.io/csw-prod/api/scala/index.html).

You can refer to Java documentation [here](https://tmtsoftware.github.io/csw-prod/api/java/?/index.html).
