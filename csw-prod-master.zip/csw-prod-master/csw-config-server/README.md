Configuration Service
=========================

Configuration Service helps storing and fetching config files of components.
It uses a Version Controlled System to store and manage these configuration files.
The server provides a REST API to access supported features.

If you want to get started with configuration service, refer the [examples](https://tmtsoftware.github.io/csw-prod/services/config.html). 